import { describe, expect, it } from 'vitest';
import { contactSchema } from '../lib/contact-validation';
const valid={name:'Freight Customer',phone:'+1 307-266-3094',email:'customer@example.com',company:'',message:'Please discuss transportation.'};
describe('contact validation',()=>{
 it('accepts a valid inquiry with an optional company',()=>expect(contactSchema.safeParse(valid).success).toBe(true));
 it('rejects missing names',()=>expect(contactSchema.safeParse({...valid,name:''}).success).toBe(false));
 it('rejects invalid phone numbers',()=>expect(contactSchema.safeParse({...valid,phone:'abc'}).success).toBe(false));
 it('rejects invalid email addresses',()=>expect(contactSchema.safeParse({...valid,email:'invalid'}).success).toBe(false));
 it('rejects an empty message',()=>expect(contactSchema.safeParse({...valid,message:''}).success).toBe(false));
});
