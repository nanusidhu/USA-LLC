import { z } from 'zod';
export const contactSchema = z.object({
 name: z.string().trim().min(2, 'Please enter your name.').max(100),
 phone: z.string().trim().refine(value => value.replace(/\D/g, '').length >= 7 && value.replace(/\D/g, '').length <= 15, 'Please enter a valid phone number.'),
 email: z.string().trim().email('Please enter a valid email address.'),
 company: z.string().trim().max(150),
 message: z.string().trim().min(10, 'Please include at least 10 characters.').max(5000),
});
