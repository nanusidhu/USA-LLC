import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, ServicesSection, ProcessSection, CtaSection } from '@/components/trucking-site';
import { pageMeta } from '@/lib/page-meta';
export const Route = createFileRoute('/services')({head:()=>pageMeta('Our Services | USA Trucking LLC', 'Discuss your freight transportation needs with USA Trucking LLC in Casper, Wyoming.', '/services'),component:Page});
function Page(){return <><PageIntro label="OUR SERVICES" title="TRANSPORTATION WITH PURPOSE." description="Discuss your freight transportation needs with USA Trucking LLC in Casper, Wyoming."/><ServicesSection full/><ProcessSection/><CtaSection/></>;}
