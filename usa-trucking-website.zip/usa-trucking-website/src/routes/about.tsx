import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, AboutSection, WhySection, CtaSection } from '@/components/trucking-site';
import { pageMeta } from '@/lib/page-meta';
export const Route = createFileRoute('/about')({head:()=>pageMeta('About Usa Trucking Llc | USA Trucking LLC', 'A professional trucking company based in Casper, Wyoming, focused on dependable transportation and customer service.', '/about'),component:Page});
function Page(){return <><PageIntro label="ABOUT USA TRUCKING LLC" title="BUILT ON THE ROAD. DRIVEN BY RELIABILITY." description="A professional trucking company based in Casper, Wyoming, focused on dependable transportation and customer service."/><AboutSection full/><WhySection/><CtaSection/></>;}
