import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, ReviewsSection, CtaSection } from '@/components/trucking-site';
import { pageMeta } from '@/lib/page-meta';
export const Route = createFileRoute('/reviews')({head:()=>pageMeta('Customer Rating | USA Trucking LLC', 'USA Trucking LLC has a customer rating of 4.5 out of 5, based on 36 reviews.', '/reviews'),component:Page});
function Page(){return <><PageIntro label="CUSTOMER RATING" title="TRUST, MILE AFTER MILE." description="USA Trucking LLC has a customer rating of 4.5 out of 5, based on 36 reviews."/><ReviewsSection full/><CtaSection/></>;}
