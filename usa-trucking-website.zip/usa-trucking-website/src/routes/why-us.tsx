import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, WhySection, ProcessSection, CtaSection } from '@/components/trucking-site';
import { pageMeta } from '@/lib/page-meta';
export const Route = createFileRoute('/why-us')({head:()=>pageMeta('The Usa Trucking Difference | USA Trucking LLC', 'Reliability, professionalism, safety, and a customer-focused approach to transportation.', '/why-us'),component:Page});
function Page(){return <><PageIntro label="THE USA TRUCKING DIFFERENCE" title="EVERY MILE MATTERS." description="Reliability, professionalism, safety, and a customer-focused approach to transportation."/><WhySection/><ProcessSection/><CtaSection/></>;}
