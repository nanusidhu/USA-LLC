import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, ContactSection, LocationSection } from '@/components/trucking-site';
import { pageMeta } from '@/lib/page-meta';
export const Route = createFileRoute('/contact')({head:()=>pageMeta('Contact Usa Trucking Llc | USA Trucking LLC', 'Contact USA Trucking LLC at +1 307-266-3094 or visit 5370 W Poison Spider Rd, Casper, Wyoming.', '/contact'),component:Page});
function Page(){return <><PageIntro label="CONTACT USA TRUCKING LLC" title="LET’S TALK TRANSPORTATION." description="Contact USA Trucking LLC at +1 307-266-3094 or visit 5370 W Poison Spider Rd, Casper, Wyoming."/><ContactSection/><LocationSection/></>;}
